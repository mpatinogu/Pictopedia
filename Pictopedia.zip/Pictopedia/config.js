var config = {
  consumer_key: 'KgLI9ui4wf6rlbN0TuGs2qpSt',//process.env.TWITTER_CONSUMER_KEY,
  consumer_secret: 's8jdFTGXuqebwTBCmAq2Wk2CHXvDlSIuYWpyaU5AvVvXIv2X5Z',//process.env.TWITTER_CONSUMER_SECRET,
  access_token_key: '35869952-HZpTZUBweslYrBeZFLlRMprYkrYvA53TuYd3hmAwW',//process.env.TWITTER_ACCESS_TOKEN_KEY,
  access_token_secret: '5tpGt2SoXhTsL6CAnx13plxJWnS9KdDInubAYuJSiaWPO'//process.env.TWITTER_ACCESS_TOKEN_SECRET
}

module.exports = config;