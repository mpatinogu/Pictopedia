/*********
Name: SearchTweets
Function: return a list of tweets from @pictoline 
Return: HTML
**************/
function SearchTweets(){
    $("#results" ).html("");
    if($('#searchTxt').val().length>2){
        $.ajax({
          url: "/searchTweets",
          data: {
            q: $('#searchTxt').val()
          },
          success: function( result ) {
            $( "#results" ).html(result);
          }
            
        });
    }
    else{
        alert("Favor de escribir una palabra válida");
    }
}

//Set the key "enter" 
$("input").keypress(function(event) {
if (event.which == 13) {
        event.preventDefault();
        $("form").submit();
    }
});